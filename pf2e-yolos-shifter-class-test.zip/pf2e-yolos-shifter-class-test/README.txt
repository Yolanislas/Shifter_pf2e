Foundry module manifest :

Note from author : 
Not everything is automatized unfortunately, be sure to check the pdf !
- Hold breath is not added as a sense
- Repostion trait can not be added to unarmed strike
- Saves from the Adaptation features are not added automatically, you must add your proeficiencies manually at level 1, 3, 9, 11, 15

I'll continue to learn more about foundry to upgrade this module
DM Yolanislas on reddit for any questions, feedback, balance issues
